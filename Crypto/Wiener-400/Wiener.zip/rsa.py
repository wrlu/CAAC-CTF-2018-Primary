from wiener_attack import wienerAttack
from Crypto.PublicKey import RSA

def egcd(a, b):
    (x, lastx) = (0, 1)
    (y, lasty) = (1, 0)
    while b != 0:
        q = a // b
        (a, b) = (b, a % b)
        (x, lastx) = (lastx - q * x, x)
        (y, lasty) = (lasty - q * y, y)
    return (lastx, lasty, a)

def modinv(a, m):
    (inv, q, gcd_val) = egcd(a, m)
    return inv % m

def encrypt():
    f = open('plaintext.txt', 'r')
    plain_text = f.read()
    f.close()
    rsa = RSA.importKey(open('rsa'))
    cipher_text = rsa.encrypt(plain_text, 1)[0]
    f = open('ciphertext.txt', 'w')
    f.write(cipher_text)
    f.close()

if __name__ == '__main__':
    encrypt()
