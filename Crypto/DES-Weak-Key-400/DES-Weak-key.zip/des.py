#!/usr/bin/env python
# -*- coding: utf-8 -*-

from Crypto.Cipher import DES


def key():
  f = open('key.txt', 'r')
  key_hex = f.readline()[:-1]
  f.close()
  return key_hex.decode("hex")

def plaintext():
  f = open('plaintext.txt', 'r')
  plain_text = f.read()
  f.close()
  return plain_text

def main():
  KEY = key()
  IV = '3826cf1d'
  cipher = DES.new(KEY, DES.MODE_OFB, IV)

  plain_text = plaintext()
  cipher_text = cipher.encrypt(plain_text)
  f = open('ciphertext.txt', 'w')
  f.write(cipher_text)
  f.close()

if __name__ == '__main__':
  main()