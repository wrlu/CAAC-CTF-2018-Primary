<?php
require_once('db.php');
if(!$_GET['id'])
{
    header("location:index?id=1");
    die('no get parameter : id');
}
$id = $_GET['id'];
$db = db_connect();
$query = "select * from userinfo where id = $id";
$result = $db->query($query);
var_dump($result);
$row_result = $result->fetch_assoc();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welecome to the CTF</title>
    <link href="rs-plugin/css/settings.css" rel="stylesheet" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/ambixo.css" rel="stylesheet">

    <!-- Script -->
    <script src="js/jquery.min.js"></script>
    <script src="rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script src="js/portfolio/modernizr.custom.js"></script>
    <script src="js/testimonial/jquery.quovolver.min.js"></script>

    <!-- Favicons -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon.png">
    <link rel="apple-touch-icon-precomposed" sizes="60x60" href="img/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="img/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/apple-touch-icon-144x144.png"> 
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="img/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="img/apple-touch-icon-152x152.png">
 

    <!-- SEO Meta Tags -->
    <!-- <meta name="description" content="" /> -->
    <!-- <meta name="keywords" content="" /> -->

    <!-- Google Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Aclonica' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Nothing+You+Could+Do' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Signika' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Signika:300' rel='stylesheet' type='text/css'>

    <!-- Font Awesome -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

  </head>
  <body data-spy="scroll" data-target=".header">
    <header>
      <div id="header" class="header">
        <div class="container">
          <h1 class="logo"><a href="#"><span>C</span>TF</a></h1>
          <h2 class="tagline hidden-xs"><span>Have</span> fun <span>in</span> the <span>CTF</span> Game</h2>
        </div>
        <a href="#about" class="sr-only">Skip to main content</a>
        <nav id="main-nav">
          <div class="navbar navbar-default" role="navigation">
            <div class="container">
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
              </div>
            </div>
          </div>
        </nav>
      </div>
      <svg class="decor" height="100" preserveaspectratio="none" version="1.1" viewbox="0 0 100 100" width="100%" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 100 L100 0 L0 0" stroke-width="0"></path>
      </svg>
    </header>

    <section id="main-img">
         <img class="img-responsive" src="img/main-img.jpg" alt="">
    </section>

    <!-- About -->
    <section id="about-1" class="section-page">
      <div class="container-fluid">
        <div class="container">
           <div>
            <div class="about col-sm-6">
              <div class="wrap-about">
                <h3><?php echo $row_result['name']; ?></h3>
                <p><?php echo $row_result['introduction'];?></p>
              </div>
            </div>
            <div class="about col-sm-6"><img class="img-responsive" src="img/man.png" alt="" /></div>
          </div>
        </div>
      </div>
    </section>

    <!-- Parallax 1 -->
    <section id="parallax-1" class="container-fluid parallax fixed" style="background-image: url(img/parallax/1.jpg)">
      <p class="parallax-text">Just for Ambitious</p>
    </section> 

    <!-- Services -->
    <section id="services" class="section-page">
      <div class="container">
        <h3 class="text-center">Services</h3>
         <div>
          <div class="col-sm-12">
            <div class="about col-sm-4">
              <h4 class="text-center text-uppercase"><i class="fa fa-desktop"></i> Web Design</h4>
                <div class="easy-pie-chart" data-percent="100">
                  <span>100<sup>%</sup></span>
                </div>
              <p class="text-center">
                Pellentesque nibh felis, eleifend id, commodo in, interdum vitae, leo. Praesent eu elit. Ut eu ligula.
                Pellentesque nibh felis, eleifend id, commodo in, interdum vitae, leo. Praesent eu elit. Ut eu ligula.
              </p>
            </div>
            <div class="about col-sm-4">
              <h4 class="text-center text-uppercase"><i class="fa fa-search"></i> SEO</h4>
                <div class="easy-pie-chart" data-percent="90">
                  <span>90<sup>%</sup></span>
                </div>
              <p class="text-center">
                Pellentesque nibh felis, eleifend id, commodo in, interdum vitae, leo. Praesent eu elit. Ut eu ligula.
                Pellentesque nibh felis, eleifend id, commodo in, interdum vitae, leo. Praesent eu elit. Ut eu ligula.
              </p>
            </div>
            <div class="about col-sm-4">
              <h4 class="text-center text-uppercase"><i class="fa fa-bullhorn"></i> Web Marketing</h4>
               <div class="easy-pie-chart" data-percent="80">
                  <span>80<sup>%</sup></span>
               </div>
              <p class="text-center">
                Pellentesque nibh felis, eleifend id, commodo in, interdum vitae, leo. Praesent eu elit. Ut eu ligula.
                Pellentesque nibh felis, eleifend id, commodo in, interdum vitae, leo. Praesent eu elit. Ut eu ligula.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Parallax 2 -->
    <section id="parallax-2" class="container-fluid parallax fixed" style="background-image: url(img/parallax/2.jpg)">
      <p class="parallax-text">Usable</p> 
    </section>

    <section id="contact-footer">
      <div class="container">
         <div>
          <div class="col-xs-12">
              <ul class="col-xs-3">
                  <li><i class="fa fa-map-marker"></i> 123 Ambixo St. <br>
                      2000 Sydney <br>
                      Google Map
                  </li>
              </ul>            
              <ul class="col-xs-3">
                  <li><i class="fa fa-phone"></i> (+00) 123.456789</li>
                  <li><i class="fa fa-envelope"></i> <a href="mailto:#">ambixo@yopmail.com</a></li>
                  <li><i class="fa fa-skype"></i> Ambixo</li>
              </ul>
              <ul class="col-xs-3">
                  <li><i class="fa fa-clock-o"></i> Mon-Fri: 9:00am &rarr; 5:30pm <br>
                    Sat: 10:00am &rarr; 2:30pm <br>
                    Sunday: Closed
                  </li>
              </ul>
              <ul class="col-xs-3">
                  <li><i class="fa fa-info-circle"></i> Aliquam lectus orci adipiscing et sodales ac feugiat non lacus ut dictum velit <span class="hidden-xs">nec est quisque posuere purus sit amet</span>
                  </li>
              </ul>
            </div>
          </div>
        </div>
    </section>
    
    <!-- Back to Top -->
    <p class="back-to-top"><i class="fa fa-chevron-up"></i></p>
      

    <!-- Bootstrap core JavaScript
    ================================================== -->

    <script src="js/bootstrap.min.js"></script>

    <!-- JavaScripts -->
    <script src="js/services/jquery.easypiechart.min.js"></script>
    <script src="js/carousel/jquery.bxslider.min.js"></script>
    <script src="js/portfolio/grid.js"></script>
    <script src="js/isotope/jquery.isotope.min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/parallax/jquery.parallax-1.1.3.js"></script>
    <script src="js/parallax/jquery.localscroll-1.2.7-min.js"></script>
    <script src="js/parallax/jquery.scrollTo-min.js"></script>
    <script src="js/ambixo.js"></script>

    <script>
      $('.easy-pie-chart').easyPieChart({
        animate: 2000,
        scaleColor: false,
        lineWidth: 20,
        lineCap: 'square',
        size: 180,
        trackColor: '#3e383a',
        barColor: '#D0C5BF',
      });
    </script>


  </body>
</html>