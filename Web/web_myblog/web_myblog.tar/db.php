<?php
function db_connect() {
    $result = new mysqli('localhost','root','root','caac');
    if (!$result){
        throw new Exception('Could not connect to the database');
    }else{
        return $result;
    }
}